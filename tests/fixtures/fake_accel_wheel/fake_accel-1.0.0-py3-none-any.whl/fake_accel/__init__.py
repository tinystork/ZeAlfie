"""Synthetic accelerated fixture package (ZA-M1-2J)."""
__version__ = "1.0.0"
